import os
import sys


from biotis.wsgi import application
sys.path.insert(0, os.path.dirname(__file__))
