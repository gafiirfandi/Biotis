from django.apps import AppConfig


class ProfilePageConfig(AppConfig):
    name = 'profile_page'
